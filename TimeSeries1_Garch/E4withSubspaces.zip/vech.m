function x = vech(X)
% Warning vech(): This function is obsolete and has been replaced by e4vech
% in order to prevent name conflicts with other toolboxes
% See e4vech.m

disp('Warning vech(): This function is obsolete and has been replaced by e4vech in order to prevent name conflicts with other toolboxes');
x = e4vech(X);

