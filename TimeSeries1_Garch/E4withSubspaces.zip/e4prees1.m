function theta2 = e4prees1(theta, din, z, userf)
%
% 7/3/97
% Copyright (c) Jaime Terceiro, 1997

global EEOPTION

if nargin < 3,  e4error(3); end
if nargin < 4,  userf = []; end

% innovations?

if din(1,1) > 7, innov = 0;
elseif din(1,1) < 7, innov = 1;
elseif din(1,1) == 7 & din(1,9) & din(10,1) == din(9,1), innov = 1;
else, innov = 0; end

[Phi, Gam, E, H, D, C, Q, S, R] = thd2ee(theta, din, userf);
N = size(z,1);
n = size(Phi,1);
m = size(H,1);
r = max([size(Gam,2), size(D,2)]);
if size(z,2) ~= m+r, e4error(11); end

if any(abs(eig(Phi)) >= EEOPTION(12)), stat = 0; else stat = 1; end

i = max(round(log(N)),ceil(n/m)+2);

if N < 2*i*(m+r+1-stat)-1, j = max(fix((N-i*(m+r+1)+1)/(m+r+1)),ceil(n/m)+1); else j = i; end
ij = i+j;

if N < ij*(m+r+1-stat)-1
   i = ceil(n/m)+1; j = i; ij = i+j;
   if N < i*(m+r+1-stat)+j*(r+1-stat)-1, error('Not enough data for using e4preest()'); end
end

missing = any(any(isnan(z(:,1:m))));
if missing
   z2 = z;
   for h=1:m
       k = find(isnan(z(:,h)));
       sk = size(k,1);
       if sk
          k2 = find(k-[min(0,k(1)-2);k(1:sk-1)] > 1);
       
          if size(k2,1) <= 1
             if k(1) == 1, z1 = z(k(sk)+1,h);
             elseif k(sk) == N, z1 = z(k(1)-1,h);
             else, z1 = (z(k(sk)+1,h) + z(k(1)-1,h))/2; end
             z2(k,h) = z1*ones(sk,1);
          else
             if k(1) == 1, z1 = z(k(k2(2)-1)+1,h);
             else, z1 = (z(k(k2(2)-1)+1,h) + z(k(1)-1,h))/2; end
             z2(k(k2(1)):k(k2(2)-1),h) = z1*ones(k(k2(2)-1)-k(k2(1))+1,1);

             for l=2:size(k2,1)-1
                 z2(k(k2(l)):k(k2(l+1)-1),h) = (z(k(k2(l))-1,h)+z(k(k2(l+1)-1)+1,h))/2*ones(k(k2(l+1)-1)-k(k2(l))+1,1);
             end
 
             if k(sk) == N, z1 = z(k(k2(l+1))-1,h);
             else, z1 = (z(k(sk)+1,h) + z(k(k2(l+1))-1,h))/2; end
             z2(k(k2(l+1)):k(sk),h) = z1*ones(k(sk)-k(k2(l+1))+1,1);
          end
       end
   end
end
   
if r
   Yi = blkhkel(z(:,1:m), ij, 1, stat);
   N = min(size(Yi,2), size(z,1));
   if missing
      K  = any(isnan(Yi));
      Yi = blkhkel(z2(:,1:m)*N/(N-sum(K)/2), ij, 1, stat);
      Ui = blkhkel(z(:,m+1:m+r)*N/(N-sum(K)/2), ij, 1, stat);
      Yi(:,K) = Yi(:,K)/2;
      Ui(:,K) = Ui(:,K)/2;
   else
      Ui = blkhkel(z(:,m+1:m+r), ij, 1, stat);
   end
   [Q, R] = qr([Ui(r*i+1:r*ij,:);Ui(1:r*i,:);Yi]', 0);
   ix = zeros(5,2);
   ix(:,1) = [1; j*r+1; ij*r+1; ij*r+i*m+1; ij*r+(i+1)*m+1];
   ix(:,2) = [ix(2:5,1)-1; ij*(m+r)];
   R = R'/sqrt(N);
else
   Yi = blkhkel(z, ij, 1, stat);
   N = min(size(Yi,2), size(z,1));
   if missing
      K  = any(isnan(Yi));
      Yi = blkhkel(z2(:,1:m)*N/(N-sum(K)/2), ij, 1, stat);
      Yi(:,K) = Yi(:,K)/2;
   end
   [Q, R] = qr(Yi', 0);
   R = R'/sqrt(N);
   ix = zeros(3,2);
   ix(:,1) = [1; i*m+1; (i+1)*m+1];
   ix(:,2) = [ix(2:3,1)-1; ij*m];
end

if size(R,1) > size(R,2)
   R = [R zeros(size(R,1), size(R,1)-size(R,2))];
   pond = 0;
else
   pond = 1;
end

sth = size(theta,1);
if size(theta,2) == 1, theta2 = [theta zeros(sth,1)]; else, theta2 = theta; end

if innov
%
   if din(1,1) > 3 & din(1,1) < 7
      m = din(1,2); r = din(1,3);
      if din(m+2,7) == 1 | din(m+2,7) == 3
         theta2(sth-r+1:sth,2) = ones(r,1);
      else
         theta2(sth-(r+1)*r/2+1:sth,2) = ones((r+1)*r/2,1);
      end
      sth = din(1,6);
   end

   if din(1,7) == 1 | din(1,7) == 3
      theta2(sth-m+1:sth,2) = ones(m,1);
   else
      theta2(sth-(m+1)*m/2+1:sth,2) = ones((m+1)*m/2,1);
   end
else
   index = e4ds(theta,din);
end

k = find(theta2(:,2)==0);

if size(k,1) > 0

%   seteeopt('verbose','no');
   if innov
      theta2(k,1) = zeros(size(k,1),1);
      theta2 = eemin('e4prees2', theta2, '', din, R, ix, [i j pond N], userf);
   else
      theta2(k,1) = zeros(size(k,1),1);
      if sum(index(k,1)) < size(k,1)
         theta2(k,2) = index(k,1);
         theta2 = eemin('e4prees3', theta2, '', din, R, ix, [i j pond N], userf);
      end
      [f, KB] = e4prees3(theta2, din, R, ix, [i j pond N], userf);
      theta2(k(index(k,2)),1) = trace(KB(n+1:n+m,:))*ones(sum(index(k,2)),1);
      theta2(k,2) = ~index(k,1);
      if sum(~index(k,1)) < size(k,1)
         theta2 = eemin('e4prees4',theta2, '',din, KB, [i j pond N], userf);
      end
   end
   sete4opt('verbose','si');
else
   pond = 0;
end

if innov
   if pond
      [f, B] = e4prees2(theta2,din,R,ix,[i j pond N],userf);
   else
      if missing
         [f e] = fvmiss(theta2,din,z,userf);
      else
         [f e] = fvarmax(theta2,din,z,userf);
      end
      B = e'*e/size(z,1);
   end

   sth = size(theta2,1);

   if din(1,1) > 3 & din(1,1) < 7
      if din(m+2,7) == 1 | din(m+2,7) == 3
         if EEOPTION(5) == 1
            theta2(sth-r+1:sth,1) = sqrt(diag(B(m+1:m+r,m+1:m+r))); 
         else
            theta2(sth-r+1:sth,1) = diag(B(m+1:m+r,m+1:m+r));
         end
      else
         B2 = B(m+1:m+r,m+1:m+r);
         if EEOPTION(5) == 1, B2 = cholp(B2); end
         tmpndx = triu(ones(r));
         theta2(sth-(r+1)*r/2+1:sth,1) = B2(tmpndx);
      end
      B = B(1:m,1:m);
      sth = din(1,6);
   end

   if din(1,7) == 1 | din(1,7) == 3
      if EEOPTION(5) == 1
         theta2(sth-m+1:sth,1) = sqrt(diag(B)); 
      else
         theta2(sth-m+1:sth,1) = diag(B);
      end
   else
      if EEOPTION(5) == 1, B = cholp(B); end
      tmpndx = triu(ones(m));
      theta2(sth-(m+1)*m/2+1:sth,1) = B(tmpndx);
   end
end

if size(theta,2) == 1, theta2 = theta2(:,1); else, theta2(:,2) = theta(:,2); end
