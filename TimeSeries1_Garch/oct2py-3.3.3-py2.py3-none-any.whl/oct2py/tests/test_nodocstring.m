function [outp] = test_nodocstring(inp)
    outp = inp;
end
